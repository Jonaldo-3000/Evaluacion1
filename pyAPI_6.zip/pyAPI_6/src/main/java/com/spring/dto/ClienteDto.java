package com.spring.dto;

import java.util.List;

import com.spring.entity.Alquiler;
import com.spring.entity.Direccion;

public class ClienteDto {
	
	private int dni;
	private String nombre;
	private String fecha_nacimiento;
	private String lugar_nacimiento;
	private String sexo;
	private String observacion;
	
	private List<Alquiler> alquileres;
	
	private Direccion direccion;

	public int getDni() {
		return dni;
	}

	public void setDni(int dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getFecha_nacimiento() {
		return fecha_nacimiento;
	}

	public void setFecha_nacimiento(String fecha_nacimiento) {
		this.fecha_nacimiento = fecha_nacimiento;
	}

	public String getLugar_nacimiento() {
		return lugar_nacimiento;
	}

	public void setLugar_nacimiento(String lugar_nacimiento) {
		this.lugar_nacimiento = lugar_nacimiento;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	public List<Alquiler> getAlquileres() {
		return alquileres;
	}

	public void setAlquileres(List<Alquiler> alquileres) {
		this.alquileres = alquileres;
	}

	public Direccion getDireccion() {
		return direccion;
	}

	public void setDireccion(Direccion direccion) {
		this.direccion = direccion;
	}

	public ClienteDto(int dni, String nombre, String fecha_nacimiento, String lugar_nacimiento, String sexo,
			String observacion, List<Alquiler> alquileres, Direccion direccion) {
		this.dni = dni;
		this.nombre = nombre;
		this.fecha_nacimiento = fecha_nacimiento;
		this.lugar_nacimiento = lugar_nacimiento;
		this.sexo = sexo;
		this.observacion = observacion;
		this.alquileres = alquileres;
		this.direccion = direccion;
	}

	public ClienteDto() {
		
	}

	
	
	

}
