package com.spring.dto;

import java.util.List;

import com.spring.entity.Alquiler;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

public class VendedorDto {
	
	@NotBlank
	private String nombre;
	private String direccion;
	@Min(0)
	private int telefono;
	private String observacion;
	@Min(0)
	private int sueldo;
	
	private List<Alquiler> alquileres;

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public int getTelefono() {
		return telefono;
	}

	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}

	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	public int getSueldo() {
		return sueldo;
	}

	public void setSueldo(int sueldo) {
		this.sueldo = sueldo;
	}

	public List<Alquiler> getAlquileres() {
		return alquileres;
	}

	public void setAlquileres(List<Alquiler> alquileres) {
		this.alquileres = alquileres;
	}

	public VendedorDto(String nombre, String direccion, int telefono, String observacion, int sueldo,
			List<Alquiler> alquileres) {
		this.nombre = nombre;
		this.direccion = direccion;
		this.telefono = telefono;
		this.observacion = observacion;
		this.sueldo = sueldo;
		this.alquileres = alquileres;
	}

	public VendedorDto() {
		
	}
	
	

}
