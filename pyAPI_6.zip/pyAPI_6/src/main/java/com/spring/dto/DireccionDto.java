package com.spring.dto;

import com.spring.entity.Cliente;

public class DireccionDto {
	
	private String calle;
    private String numero;
    private String ciudad;
    
    private Cliente cliente;

	public String getCalle() {
		return calle;
	}

	public void setCalle(String calle) {
		this.calle = calle;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public DireccionDto(String calle, String numero, String ciudad, Cliente cliente) {
		this.calle = calle;
		this.numero = numero;
		this.ciudad = ciudad;
		this.cliente = cliente;
	}

	public DireccionDto() {
		
	}
    
    

}
