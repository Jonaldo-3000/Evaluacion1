package com.spring.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Alquiler {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private int precio;
	private String fecha_entrada;
	private String fecha_salida;
	private String observacion;
	
	@ManyToOne
	@JsonIgnore
	private Habitacion habitacion;
	
	@ManyToOne
	@JsonIgnore
	private Vendedor vendedor;
	
	@ManyToOne
	@JsonIgnore
	private Cliente cliente;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPrecio() {
		return precio;
	}

	public void setPrecio(int precio) {
		this.precio = precio;
	}

	public String getFecha_entrada() {
		return fecha_entrada;
	}

	public void setFecha_entrada(String fecha_entrada) {
		this.fecha_entrada = fecha_entrada;
	}

	public String getFecha_salida() {
		return fecha_salida;
	}

	public void setFecha_salida(String fecha_salida) {
		this.fecha_salida = fecha_salida;
	}

	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	public Habitacion getHabitacion() {
		return habitacion;
	}

	public void setHabitacion(Habitacion habitacion) {
		this.habitacion = habitacion;
	}

	public Vendedor getVendedor() {
		return vendedor;
	}

	public void setVendedor(Vendedor vendedor) {
		this.vendedor = vendedor;
	}

	public Alquiler(int id, int precio, String fecha_entrada, String fecha_salida, String observacion,
			Habitacion habitacion, Vendedor vendedor) {
		this.id = id;
		this.precio = precio;
		this.fecha_entrada = fecha_entrada;
		this.fecha_salida = fecha_salida;
		this.observacion = observacion;
		this.habitacion = habitacion;
		this.vendedor = vendedor;
	}

	public Alquiler() {
		
	}
	
	
}
