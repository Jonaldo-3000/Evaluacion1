package com.spring.entity;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Habitacion {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private int numero_camas;
	private String descripcion;
	private int precio;
	private String observacion;
	
	@ManyToOne
	private Tipo tipo;
	
	@OneToMany(mappedBy = "habitacion")
	private List<Alquiler> alquileres;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getNumero_camas() {
		return numero_camas;
	}

	public void setNumero_camas(int numero_camas) {
		this.numero_camas = numero_camas;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public int getPrecio() {
		return precio;
	}

	public void setPrecio(int precio) {
		this.precio = precio;
	}

	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	public Tipo getTipo() {
		return tipo;
	}

	public void setTipo(Tipo tipo) {
		this.tipo = tipo;
	}

	public Habitacion(int id, int numero_camas, String descripcion, int precio, String observacion, Tipo tipo) {
		this.id = id;
		this.numero_camas = numero_camas;
		this.descripcion = descripcion;
		this.precio = precio;
		this.observacion = observacion;
		this.tipo = tipo;
	}

	public Habitacion() {
		
	}
	
	
	
}
