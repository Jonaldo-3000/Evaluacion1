package com.spring.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.entity.Direccion;

public interface DireccionRepository extends JpaRepository<Direccion,Integer>{
	
	public Optional<Direccion> findByCalle(String calle);
	public boolean existsByCalle(String calle);

}
