package com.spring.controller;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.dto.ClienteDto;
import com.spring.entity.Cliente;
import com.spring.entity.Mensaje;
import com.spring.service.ClienteService;

@RestController
@RequestMapping("/cliente")
public class ClienteController {
	
	@Autowired
	ClienteService clienteService;
	
	@GetMapping("/lista")
	public ResponseEntity<List<Cliente>> listar() {
		List<Cliente> listaCliente = clienteService.listar();
		return new ResponseEntity<List<Cliente>>(listaCliente,HttpStatus.OK);
	}
	
	@GetMapping("/lista2")
	public List<Cliente> listar2() {
		List<Cliente> listaCliente = clienteService.listar();
		return listaCliente;
	}
	
	@GetMapping("/detalle/{id}")
	public ResponseEntity<Cliente> getById(@PathVariable("id") int id) {
		if (!clienteService.existsById(id)) {
			return new ResponseEntity(new Mensaje("No existen clientes con este codigo"),HttpStatus.NOT_FOUND);
		} else {
			Cliente cliente = clienteService.getOne(id).get();
			return new ResponseEntity<Cliente>(cliente,HttpStatus.OK);
		}
	}
	
	@GetMapping("/detallexnombre/{nombre}")
	public ResponseEntity<Cliente> getByNombre(@PathVariable("nombre") String nombre){
		if (!clienteService.existsByNombre(nombre)) {
			return new ResponseEntity(new Mensaje("No se puede detalar porque el cliente no existe"),HttpStatus.NOT_FOUND);
		} else {
			Cliente cliente = clienteService.getByNombre(nombre).get();
			return new ResponseEntity(cliente,HttpStatus.OK);
		}
	}
	
	@PostMapping("/create")
	public ResponseEntity<?> create(@RequestBody ClienteDto clienteDto){
		if (clienteDto.getDni()<10000000) {
			return new ResponseEntity(new Mensaje("Dni no valido"),HttpStatus.BAD_REQUEST);
		}
		if (StringUtils.isBlank(clienteDto.getNombre())) {
			return new ResponseEntity(new Mensaje("Nombre no debe ser nulo"),HttpStatus.BAD_REQUEST);
		} 
		if (StringUtils.isBlank(clienteDto.getFecha_nacimiento())) {
			return new ResponseEntity(new Mensaje("Fecha nacimiento no debe ser nulo"),HttpStatus.BAD_REQUEST);
		}
		if (StringUtils.isBlank(clienteDto.getLugar_nacimiento())) {
			return new ResponseEntity(new Mensaje("Lugar nacimiento no debe ser nulo"),HttpStatus.BAD_REQUEST);
		}
		if (StringUtils.isBlank(clienteDto.getSexo())) {
			return new ResponseEntity(new Mensaje("Sexo no debe ser nulo"),HttpStatus.BAD_REQUEST);
		}
		if (StringUtils.isBlank(clienteDto.getObservacion())) {
			return new ResponseEntity(new Mensaje("Observacion no debe ser nulo"),HttpStatus.BAD_REQUEST);
		}
		Cliente cliente = new Cliente(0, clienteDto.getDni(),clienteDto.getNombre(),clienteDto.getFecha_nacimiento(),
				                      clienteDto.getLugar_nacimiento(),clienteDto.getSexo(),clienteDto.getObservacion(), null, null);
		System.out.println(cliente.toString());
		clienteService.save(cliente);
		return new ResponseEntity(new Mensaje("Cliente insertado"),HttpStatus.OK);
	}
	
	@PutMapping("/update/{id}")
	   public  ResponseEntity<?> update(@PathVariable ("id") int id, @RequestBody ClienteDto clienteDto) {
		   if (!clienteService.existsById(id)) {
			  return new ResponseEntity(new Mensaje("No existen datos con este código"), HttpStatus.NOT_FOUND);   
		   }
		   if (clienteService.existsByNombre(clienteDto.getNombre()) &&
				   clienteService.getByNombre(clienteDto.getNombre()).get().getId()!=id) {
			   return new ResponseEntity(new Mensaje("Ya existe un cliente con ese nombre"),HttpStatus.BAD_REQUEST);
		   }
		   if (clienteDto.getDni()<10000000) {
				return new ResponseEntity(new Mensaje("Dni no valido"),HttpStatus.BAD_REQUEST);
			}
			if (StringUtils.isBlank(clienteDto.getNombre())) {
				return new ResponseEntity(new Mensaje("Nombre no debe ser nulo"),HttpStatus.BAD_REQUEST);
			} 
			if (StringUtils.isBlank(clienteDto.getFecha_nacimiento())) {
				return new ResponseEntity(new Mensaje("Fecha nacimiento no debe ser nulo"),HttpStatus.BAD_REQUEST);
			}
			if (StringUtils.isBlank(clienteDto.getLugar_nacimiento())) {
				return new ResponseEntity(new Mensaje("Lugar nacimiento no debe ser nulo"),HttpStatus.BAD_REQUEST);
			}
			if (StringUtils.isBlank(clienteDto.getSexo())) {
				return new ResponseEntity(new Mensaje("Sexo no debe ser nulo"),HttpStatus.BAD_REQUEST);
			}
			if (StringUtils.isBlank(clienteDto.getObservacion())) {
				return new ResponseEntity(new Mensaje("Observacion no debe ser nulo"),HttpStatus.BAD_REQUEST);
			}
		   Cliente cliente = clienteService.getOne(id).get();
		   cliente.setDni(clienteDto.getDni());
		   cliente.setNombre(clienteDto.getNombre());
		   cliente.setFecha_nacimiento(clienteDto.getFecha_nacimiento());
		   cliente.setLugar_nacimiento(clienteDto.getLugar_nacimiento());
		   cliente.setSexo(clienteDto.getSexo());
		   cliente.setObservacion(clienteDto.getObservacion());
		   clienteService.save(cliente);
		   return new ResponseEntity(new Mensaje("Cliente actualizado"),HttpStatus.OK);
	   }
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> delete(@PathVariable("id") int id) {
		if (!clienteService.existsById(id)) {
			return new ResponseEntity(new Mensaje("Cliente a eliminar no existe"),HttpStatus.BAD_REQUEST);
		} else {
			clienteService.delete(id);
			return new ResponseEntity(new Mensaje("Cliente eliminado"),HttpStatus.OK);
		}
	}

}
