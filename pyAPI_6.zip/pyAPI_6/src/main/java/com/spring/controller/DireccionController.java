package com.spring.controller;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.dto.DireccionDto;
import com.spring.entity.Direccion;
import com.spring.entity.Mensaje;
import com.spring.service.DireccionService;

@RestController
@RequestMapping("/direccion")
public class DireccionController {
	
	@Autowired
	DireccionService direccionService;
	
	@GetMapping("/lista")
	public ResponseEntity<List<Direccion>> listar() {
		List<Direccion> listaDireccion = direccionService.listar();
		return new ResponseEntity<List<Direccion>>(listaDireccion,HttpStatus.OK);
	}
	
	@GetMapping("/lista2")
	public List<Direccion> listar2() {
		List<Direccion> listaDireccion = direccionService.listar();
		return listaDireccion;
	}
	
	@GetMapping("/detalle/{id}")
	public ResponseEntity<Direccion> getById(@PathVariable("id") int id) {
		if (!direccionService.existsById(id)) {
			return new ResponseEntity(new Mensaje("No existen direcciones con este codigo"),HttpStatus.NOT_FOUND);
		} else {
			Direccion direccion = direccionService.getOne(id).get();
			return new ResponseEntity<Direccion>(direccion,HttpStatus.OK);
		}
	}
	
	@GetMapping("/detallexcalle/{calle}")
	public ResponseEntity<Direccion> getByCalle(@PathVariable("calle") String calle){
		if (!direccionService.existsByCalle(calle)) {
			return new ResponseEntity(new Mensaje("No se puede detalar porque la calle no existe"),HttpStatus.NOT_FOUND);
		} else {
			Direccion direccion = direccionService.getByCalle(calle).get();
			return new ResponseEntity(direccion,HttpStatus.OK);
		}
	}
	
	@PostMapping("/create")
	public ResponseEntity<?> create(@RequestBody DireccionDto direccionDto){
		if (StringUtils.isBlank(direccionDto.getCalle())) {
			return new ResponseEntity(new Mensaje("Calle no debe ser nulo"),HttpStatus.BAD_REQUEST);
		} 
		if (StringUtils.isBlank(direccionDto.getNumero())) {
			return new ResponseEntity(new Mensaje("Numero no debe ser nulo"),HttpStatus.BAD_REQUEST);
		}
		if (StringUtils.isBlank(direccionDto.getCiudad())) {
			return new ResponseEntity(new Mensaje("Ciudad no debe ser nulo"),HttpStatus.BAD_REQUEST);
		}
		Direccion direccion = new Direccion(0, direccionDto.getCalle(),direccionDto.getNumero(),direccionDto.getCiudad(), null);
		System.out.println(direccion.toString());
		direccionService.save(direccion);
		return new ResponseEntity(new Mensaje("Direccion insertado"),HttpStatus.OK);
	}
	
	@PutMapping("/update/{id}")
	   public  ResponseEntity<?> update(@PathVariable ("id") int id, @RequestBody DireccionDto direccionDto) {
		   if (!direccionService.existsById(id)) {
			  return new ResponseEntity(new Mensaje("No existen datos con este código"), HttpStatus.NOT_FOUND);   
		   }
			if (StringUtils.isBlank(direccionDto.getCalle())) {
				return new ResponseEntity(new Mensaje("Calle no debe ser nulo"),HttpStatus.BAD_REQUEST);
			} 
			if (StringUtils.isBlank(direccionDto.getNumero())) {
				return new ResponseEntity(new Mensaje("Numero no debe ser nulo"),HttpStatus.BAD_REQUEST);
			}
			if (StringUtils.isBlank(direccionDto.getCiudad())) {
				return new ResponseEntity(new Mensaje("Ciudad no debe ser nulo"),HttpStatus.BAD_REQUEST);
			}
			Direccion direccion = direccionService.getOne(id).get();
			direccion.setCalle(direccionDto.getCalle());
			direccion.setNumero(direccionDto.getNumero());
			direccion.setCiudad(direccionDto.getCiudad());
		   direccionService.save(direccion);
		   return new ResponseEntity(new Mensaje("Direccion actualizado"),HttpStatus.OK);
	   }
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> delete(@PathVariable("id") int id) {
		if (!direccionService.existsById(id)) {
			return new ResponseEntity(new Mensaje("Direccion a eliminar no existe"),HttpStatus.BAD_REQUEST);
		} else {
			direccionService.delete(id);
			return new ResponseEntity(new Mensaje("Direccion eliminado"),HttpStatus.OK);
		}
	}

}
