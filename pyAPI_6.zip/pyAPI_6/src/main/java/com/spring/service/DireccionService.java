package com.spring.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.entity.Direccion;
import com.spring.repository.DireccionRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class DireccionService {
	
	@Autowired
	DireccionRepository direccionRepository;
	
	public List<Direccion> listar() {
		return direccionRepository.findAll();
	}
	
	public Optional<Direccion> getOne(int id) {
		return direccionRepository.findById(id);
	}
	
	public Optional<Direccion> getByCalle(String calle) {
		return direccionRepository.findByCalle(calle);
	}
	
	public void save(Direccion cliente) {
		direccionRepository.save(cliente);
	}
	
	public void delete(int id) {
		direccionRepository.deleteById(id);
	}
	
	public void delete2(Direccion cliente) {
		direccionRepository.deleteById(cliente.getId());
	}
	
	public boolean existsById(int id) {
		return direccionRepository.existsById(id);
	}
	
	public boolean existsByCalle(String calle) {
		return direccionRepository.existsByCalle(calle);
	}

}
