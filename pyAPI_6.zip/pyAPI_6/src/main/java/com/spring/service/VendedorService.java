package com.spring.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.entity.Vendedor;
import com.spring.repository.VendedorRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class VendedorService {
	
	@Autowired
	VendedorRepository vendedorRepository;
	
	public List<Vendedor> listar() {
		return vendedorRepository.findAll();
	}
	
	public Optional<Vendedor> getOne(int id) {
		return vendedorRepository.findById(id);
	}
	
	public Optional<Vendedor> getByNombre(String nombre) {
		return vendedorRepository.findByNombre(nombre);
	}
	
	public void save(Vendedor vendedor) {
		vendedorRepository.save(vendedor);
	}
	
	public void delete(int id) {
		vendedorRepository.deleteById(id);
	}
	
	public void delete2(Vendedor vendedor) {
		vendedorRepository.deleteById(vendedor.getId());
	}
	
	public boolean existsById(int id) {
		return vendedorRepository.existsById(id);
	}
	
	public boolean existsByNombre(String nombre) {
		return vendedorRepository.existsByNombre(nombre);
	}

}
